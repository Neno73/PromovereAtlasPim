/**
 * sync-configuration controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::sync-configuration.sync-configuration');
