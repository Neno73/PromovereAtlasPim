/**
 * sync-configuration router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::sync-configuration.sync-configuration');
